package com.example.tienda;

import static android.icu.lang.UCharacter.GraphemeClusterBreak.V;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class coca extends AppCompatActivity {





    private int cantidadProductos = 0;
    private double precioTotal = 0.0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_coca);

        Intent intent = getIntent();
        int cantidadProductos = intent.getIntExtra("cantidadProductos", 0);
        double precioTotal = intent.getDoubleExtra("precioTotal", 0.0);

        TextView tvProducto = findViewById(R.id.tv_producto);
        tvProducto.setText("Seleccionaste "+cantidadProductos+" coca cola ");

        TextView tvPrecioTotal = findViewById(R.id.tv_precio_total);
        tvPrecioTotal.setText("Precio Total: $" + precioTotal);

        TextView tvDetalle = findViewById(R.id.Detalles);
        tvDetalle.setText("Producto: coca" +
                "\nCantidad: "+cantidadProductos+"" +
                "\nPeso: 2.5ml" +
                "\nMarca: coca");
    }

    public void Mas(View view) {
        cantidadProductos++;
        precioTotal += 30.0;

        TextView tvCantidad = findViewById(R.id.tv_cantidad);
        tvCantidad.setText(Integer.toString(cantidadProductos));
    }

    public void Menos(View view) {
        if (cantidadProductos > 0) {
            cantidadProductos--;
            precioTotal -= 30.0;

            TextView tvCantidad = findViewById(R.id.tv_cantidad);
            tvCantidad.setText(Integer.toString(cantidadProductos));
        }
    }



    public void btn2(View view){
        Intent regresar=new Intent(this, inicia.class);
        startActivity(regresar);
    }

    public void Inicio(View view){
        Intent inicio=new Intent(this, refrescos.class);
        startActivity(inicio);
    }

}


