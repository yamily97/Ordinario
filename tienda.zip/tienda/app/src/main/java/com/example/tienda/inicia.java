package com.example.tienda;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Toast;

public class inicia extends AppCompatActivity {
    Button  salir;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inicia);

        salir = (Button) findViewById(R.id.salir);
    }
    public void mensajerefrescos (View view) {
        Toast.makeText(this, "ELEGISTE LA OPCION DE REFRESCOS", Toast.LENGTH_SHORT).show();
        Intent i= new Intent(getApplicationContext(),refrescos.class);
        startActivity(i);
    }




    public void mensajelimpieza(View view) {
        Toast.makeText(this, "ELEGISTE ARTICULOS DE LIMPIEZA", Toast.LENGTH_SHORT).show();


        Intent i= new Intent(getApplicationContext(),limpieza.class);
        startActivity(i);
    }
    public void mensajeenlatados(View view) {
        Toast.makeText(this, "ELEGISTE ARTICULOS EN LATADOS", Toast.LENGTH_SHORT).show();
        Intent i= new Intent(getApplicationContext(),enlatados.class);
        startActivity(i);





         salir.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Toast.makeText(getApplicationContext(), "regresastes a registro", Toast.LENGTH_SHORT).show();
            Intent i= new Intent(getApplicationContext(),registro.class);
            startActivity(i);
        }
    });

}
}

