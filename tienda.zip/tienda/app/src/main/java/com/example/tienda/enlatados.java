package com.example.tienda;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class enlatados extends AppCompatActivity {

    Button salir;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_enlatados);


        salir = (Button) findViewById(R.id.salir);
    }
    public void mensajefrijol(View view) {
        Toast.makeText(this, "selecionaste frijol", Toast.LENGTH_SHORT).show();
        Intent i= new Intent(getApplicationContext(),frijol.class);
        startActivity(i);
    }



    public void mensajechampiones(View view) {
        Toast.makeText(this, "selecionaste championes", Toast.LENGTH_SHORT).show();
        Intent i= new Intent(getApplicationContext(),champi.class);
        startActivity(i);



        salir.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(), "regresaste a inicio", Toast.LENGTH_SHORT).show();
                Intent i = new Intent(getApplicationContext(), inicia.class);
                startActivity(i);
            }
        });

    }
}