package com.example.tienda;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class champi extends AppCompatActivity {

    private int cantidadProductos = 0;
    private double precioTotal = 0.0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_champi);

        Intent intent = getIntent();
        int cantidadProductos = intent.getIntExtra("cantidadProductos", 0);
        double precioTotal = intent.getDoubleExtra("precioTotal", 0.0);

        TextView tvProducto = findViewById(R.id.tv_producto);
        tvProducto.setText("Seleccionaste "+cantidadProductos+" champiniones ");

        TextView tvPrecioTotal = findViewById(R.id.tv_precio_total);
        tvPrecioTotal.setText("Precio Total: $" + precioTotal);

        TextView tvDetalle = findViewById(R.id.tv_Detalles);
        tvDetalle.setText("Producto: champiñiones en trozo;" +
                "\nCantidad: "+cantidadProductos+"" +
                "\nPeso: 900g" +
                "\nMarca:monte blanco");
    }

    public void Mas(View view) {
        cantidadProductos++;
        precioTotal += 45.0;

        TextView tvCantidad = findViewById(R.id.tv_cantidad);
        tvCantidad.setText(Integer.toString(cantidadProductos));
    }

    public void Menos(View view) {
        if (cantidadProductos > 0) {
            cantidadProductos--;
            precioTotal -= 45.0;

            TextView tvCantidad = findViewById(R.id.tv_cantidad);
            tvCantidad.setText(Integer.toString(cantidadProductos));
        }
    }



    public void btn2(View view){
        Intent regresar=new Intent(this, enlatados.class);
        startActivity(regresar);
    }

    public void Inicio(View view){
        Intent inicio=new Intent(this, refrescos.class);
        startActivity(inicio);
    }

}


