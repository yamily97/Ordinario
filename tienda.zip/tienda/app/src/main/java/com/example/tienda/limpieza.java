package com.example.tienda;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class limpieza extends AppCompatActivity {
    Button btn2;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_limpieza);


        btn2= (Button) findViewById(R.id.salir);
    }
    public void mensajeaxion(View view) {
        Toast.makeText(this, "selecionaste lavatrastes axion", Toast.LENGTH_SHORT).show();
        Intent i= new Intent(getApplicationContext(),axion.class);
        startActivity(i);
    }


    public void mensajefabuloso(View view) {
        Toast.makeText(this, "selecionaste fabuloso ", Toast.LENGTH_SHORT).show();
        Intent i= new Intent(getApplicationContext(),fabuloso.class);
        startActivity(i);




        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(), "Saliste de la aplicación", Toast.LENGTH_SHORT).show();
                Intent i = new Intent(getApplicationContext(), inicia.class);
                startActivity(i);
            }
        });

    }
}
