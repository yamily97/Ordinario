package com.example.tienda;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class axionpago extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {

    }
}