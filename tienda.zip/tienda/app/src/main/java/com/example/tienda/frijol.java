package com.example.tienda;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class frijol extends AppCompatActivity {

    private int cantidadProductos = 0;
    private double precioTotal= 0.0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_frijol);

        Intent intent = getIntent();
        int cantidadProductos = intent.getIntExtra("cantidadProductos", 0);
        double precioTotal = intent.getDoubleExtra("precioTotal", 0.0);

        TextView tvProducto = findViewById(R.id.tv_producto);
        tvProducto.setText("Seleccionaste "+cantidadProductos+" coca cola ");

        TextView tvPrecioTotal = findViewById(R.id.tv_precio_total);
        tvPrecioTotal.setText("Precio Total: $" + precioTotal);

        TextView tvDetalle = findViewById(R.id.Detalles);
        tvDetalle.setText("Producto: frijoles charros" +
                "\nCantidad: "+cantidadProductos+"" +
                "\nPeso: 560G." +
                "\nMarca: la costeña ");
    }

    public void Mas(View view) {
        cantidadProductos++;
        precioTotal += 20.0;

        TextView tvCantidad = findViewById(R.id.tv_cantidad);
        tvCantidad.setText(Integer.toString(cantidadProductos));
    }

    public void Menos(View view) {
        if (cantidadProductos > 0) {
            cantidadProductos--;
            precioTotal -= 20.0;

            TextView tvCantidad = findViewById(R.id.tv_cantidad);
            tvCantidad.setText(Integer.toString(cantidadProductos));
        }
    }





    public void Inicio(View view){
        Intent inicio=new Intent(this, inicia.class);
        startActivity(inicio);
    }

}


